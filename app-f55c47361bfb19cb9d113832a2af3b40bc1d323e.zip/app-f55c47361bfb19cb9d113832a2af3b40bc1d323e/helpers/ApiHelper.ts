interface CustomFetchSettings {
   method?: string;
   data?: any;
   bonusHeaders?: any;
   token?: string;
   isFormData?: boolean;
}

const ApiHelper = {
   API_URL: 'http://localhost:8000/api',

   async fetch(
      endpoint: string,
      settings: CustomFetchSettings = {
         method: 'GET',
         data: null,
         bonusHeaders: {},
      }
   ) {
      const debug = true;
      let url = ApiHelper.API_URL + endpoint;
      let headers = {
         Accept: 'application/json',
         ...settings.bonusHeaders,
      };
      if (!settings.isFormData) {
         headers['Content-Type'] = 'application/json';
      }
      if (settings.token) {
         headers['Authorization'] = 'Bearer ' + settings.token;
      }
      try {
         let fetchSettings: RequestInit = {
            method: settings.method,
            headers,
         };
         if (settings.data) {
            if (settings.method != 'GET' && settings.method != 'HEAD') {
               if (settings.isFormData) {
                  fetchSettings.body = settings.data;
               } else {
                  fetchSettings.body = JSON.stringify(settings.data);
               }
            } else {
               let params = new URLSearchParams(settings.data);
               url += '?' + params;
            }
         }
         let response = await fetch(url, fetchSettings);
         if (debug) {
            console.log('API REQUEST', url, headers, settings.data);
         }
         let jsonResponse = await response.json();
         if (debug) {
            console.log('settings, ', settings);
         }
         if (debug) {
            console.log('API RESPONSE JSON ::', jsonResponse);
         }
         return jsonResponse;
      } catch (error: any) {
         if (debug) {
            console.log('API FETCH error', error);
         }
      }
   },
};

export default ApiHelper;
