/** @type {import('next').NextConfig} */

const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  sassOptions: {
    additionalData: `@import "styles/globals/_variables.scss";@import "styles/globals/_animations.scss";`,
  },
};

module.exports = nextConfig;