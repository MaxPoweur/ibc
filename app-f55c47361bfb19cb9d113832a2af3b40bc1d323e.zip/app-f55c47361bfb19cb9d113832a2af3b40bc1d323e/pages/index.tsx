import { NextPage } from 'next';

const Index: NextPage = () => {
   return (
      <>
            <main>
            </main>
      </>
   );
};

export default Index;
