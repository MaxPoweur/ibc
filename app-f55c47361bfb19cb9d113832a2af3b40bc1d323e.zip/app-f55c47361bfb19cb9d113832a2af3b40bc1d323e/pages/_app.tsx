import '../styles/globals/_reset.scss';
import 'antd/dist/antd.min.css';
import '../styles/globals/app.scss';

import type { AppProps } from 'next/app';
import Layout from '../layout/Layout';

function App({ Component, pageProps }: AppProps) {
   return (
      <Layout>
         <Component {...pageProps} />
      </Layout>
   );
}

export default App;
