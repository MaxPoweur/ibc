const Footer = () => {
   return (
      <footer className="footer">
         <div className="footer-main">
            <div className="footer-span">
               <span>Le GIP Alfa Centre-Val de Loire, CARIF-OREF de la Région Centre-Val de Loire</span>
            </div>
            <div className="footer-cgu">
               <span>Site Étoile</span>
               <span>Nous contacter</span>
               <span>Mentions légales</span>
            </div>
         </div>
      </footer>
   );
};

export default Footer;
