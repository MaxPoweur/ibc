import React, { useState } from 'react';
import Head from 'next/head';
import Topbar from './Topbar';
import Footer from './Footer';

interface LayoutProps {
  children: React.ReactNode;
  loggedIn: boolean;
  user: string;
}

const Layout = (props: LayoutProps) => {
  const { children } = props;
  const [loggedIn, setLoggedIn] = useState(true);
  const [user, setUser] = useState('Sophie STIKKER');

  return (
    <div>
      <Head>
        <title>Titre</title>
        <meta name="description" content="Description" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <Topbar loggedIn={loggedIn} user={user} />
      <div className="page-container">{children}</div>
      <Footer />
    </div>
  );
};

export default Layout;
