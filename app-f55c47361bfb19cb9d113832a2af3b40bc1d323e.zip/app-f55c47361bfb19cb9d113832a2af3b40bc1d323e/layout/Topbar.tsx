import { BsHouseDoor } from 'react-icons/bs';
import { GoTriangleDown } from 'react-icons/go';
import Image from 'next/image';
import logoIbc from '../assets/pictures/logo-ibc.png';
import logoGipAlfa from '../assets/pictures/topbar-gip-alfa.png';
import logoInvest from '../assets/pictures/topbar-invest.png';
import logoMinistery from '../assets/pictures/topbar-ministery.png';
import logoUser from '../assets/pictures/topbar-user-icon.png';

interface TopbarProps {
  loggedIn: boolean;
  user: string;
}

const Topbar = (props: TopbarProps) => {
    // if ( props.loggedIn ) {
    // console.log('on est loggedIn');
    // } 
    // else {
    //   console.log('NON, on est pas loggedIn');
    // }
  
  return (
    <div className="topbar">
      <div className="topbar-main">
        <div className="topbar-left">
          <Image 
            src={logoIbc}
            alt="identification des besoins en compétences des entreprises"
            width="200px"
            height="50px"
          />
        </div>
        <div className="topbar-center">
          <div className="logo-center">
            <Image 
              src={logoMinistery}
              alt="ministère du travail, de l'emploi et de l'insertion"
              width="90px"
              height="50px"
            />
          </div>
          <div className="logo-center">
            <Image 
              src={logoInvest}
              alt="investir dans vos compétences"
              width="140px"
              height="50px"
            />
          </div>
          <div className="logo-center">
          <Image 
              src={logoGipAlfa}
              alt="gip alfa centre-val de loire"
              width="60px"
              height="50px"
            />
          </div>
        </div>    
        <div className="topbar-right">
          {props.loggedIn ?
          <div className="topbar-right-connected">
            <div className="user-connected">
              <span>Bonjour,</span>
              <span className="user-name">{props.user}</span>
            </div>
            <div className="user-img">
              <Image 
                src={logoUser}
                alt="logo user"
                width="50px"
                height="50px"
              />
            </div>
            <div className="user-arrow">
              <span><GoTriangleDown size={15}/></span>
            </div>
          </div>
          : <span className="topbar-right-signin">S'inscrire / se connecter</span>}
        </div>
      </div>
      <div className="topbar-bottom">
        {props.loggedIn ? 
        <div className="topbar-bottom-menu">
            <div className="menu-item">
              <span><BsHouseDoor size={20}/></span>
            </div>
            <div className="menu-item"><span>Mon espace</span></div>
            <div className="menu-item"><span>Mes salariés</span></div>
            <div className="menu-item"><span>Mon diagnostic</span></div>
        </div> 
        : <span>Observatoire des compétences attendues et particulières aux territoires de la Région Centre Val de Loire</span>}
      </div>
    </div>
  );
};

export default Topbar;
